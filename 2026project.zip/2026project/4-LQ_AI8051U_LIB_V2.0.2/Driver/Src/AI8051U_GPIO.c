/*---------------------------------------------------------------------*/
/* ------------------- Web: www.STCAI.com -----------------------------*/
/*---------------------------------------------------------------------*/

#include	"AI8051U_GPIO.h"

//========================================================================
// ����: void GPIO_Config(GPIO_port GPIO, GPIO_InitTypeDef *GPIOx)
// ����: ��ʼ��IO��.
// ����: GPIOx: �ṹ����,��ο�ͷ�ļ���Ķ���.
// �汾: V1.0, 2012-10-22
//========================================================================
void GPIO_Config(GPIO_port GPIO, GPIO_InitTypeDef *GPIOx)
{
	if(GPIO > GPIO_P7)	return;	//����
	if(GPIO == GPIO_P0)
	{
		if(GPIOx->Mode == GPIO_Mode_Out_IN)         P0M0 &= ~GPIOx->Pin, P0M1 &= ~GPIOx->Pin;   // ����׼˫���   00
        if(GPIOx->Mode == GPIO_Mode_IN_FLOATING)    P0M0 &= ~GPIOx->Pin, P0M1 |=  GPIOx->Pin;   // ���踡������   01
		if(GPIOx->Mode == GPIO_Mode_Out_PP)         P0M0 |=  GPIOx->Pin, P0M1 &= ~GPIOx->Pin;   // �������       10
		if(GPIOx->Mode == GPIO_Mode_Out_OD)         P0M0 |=  GPIOx->Pin, P0M1 |=  GPIOx->Pin;   // ��©���       11
	}
    if(GPIO == GPIO_P1)
	{
        if(GPIOx->Mode == GPIO_Mode_Out_IN)         P1M0 &= ~GPIOx->Pin, P1M1 &= ~GPIOx->Pin;
        if(GPIOx->Mode == GPIO_Mode_IN_FLOATING)    P1M0 &= ~GPIOx->Pin, P1M1 |=  GPIOx->Pin;
        if(GPIOx->Mode == GPIO_Mode_Out_PP)         P1M0 |=  GPIOx->Pin, P1M1 &= ~GPIOx->Pin;
        if(GPIOx->Mode == GPIO_Mode_Out_OD)         P1M0 |=  GPIOx->Pin, P1M1 |=  GPIOx->Pin;
	}
    if(GPIO == GPIO_P2)
    {
		if(GPIOx->Mode == GPIO_Mode_Out_IN)         P2M0 &= ~GPIOx->Pin, P2M1 &= ~GPIOx->Pin;
        if(GPIOx->Mode == GPIO_Mode_IN_FLOATING)    P2M0 &= ~GPIOx->Pin, P2M1 |=  GPIOx->Pin;
		if(GPIOx->Mode == GPIO_Mode_Out_PP)         P2M0 |=  GPIOx->Pin, P2M1 &= ~GPIOx->Pin;
		if(GPIOx->Mode == GPIO_Mode_Out_OD)         P2M0 |=  GPIOx->Pin, P2M1 |=  GPIOx->Pin;
    }
    if(GPIO == GPIO_P3)
    {
		if(GPIOx->Mode == GPIO_Mode_Out_IN)         P3M0 &= ~GPIOx->Pin, P3M1 &= ~GPIOx->Pin;
        if(GPIOx->Mode == GPIO_Mode_IN_FLOATING)    P3M0 &= ~GPIOx->Pin, P3M1 |=  GPIOx->Pin;
		if(GPIOx->Mode == GPIO_Mode_Out_PP)         P3M0 |=  GPIOx->Pin, P3M1 &= ~GPIOx->Pin;
		if(GPIOx->Mode == GPIO_Mode_Out_OD)         P3M0 |=  GPIOx->Pin, P3M1 |=  GPIOx->Pin;
    }
    if(GPIO == GPIO_P4)
    {
		if(GPIOx->Mode == GPIO_Mode_Out_IN)         P4M0 &= ~GPIOx->Pin, P4M1 &= ~GPIOx->Pin;
        if(GPIOx->Mode == GPIO_Mode_IN_FLOATING)    P4M0 &= ~GPIOx->Pin, P4M1 |=  GPIOx->Pin;
		if(GPIOx->Mode == GPIO_Mode_Out_PP)         P4M0 |=  GPIOx->Pin, P4M1 &= ~GPIOx->Pin;
		if(GPIOx->Mode == GPIO_Mode_Out_OD)         P4M0 |=  GPIOx->Pin, P4M1 |=  GPIOx->Pin;
    }
    if(GPIO == GPIO_P5)
    {
		if(GPIOx->Mode == GPIO_Mode_Out_IN)         P5M0 &= ~GPIOx->Pin, P5M1 &= ~GPIOx->Pin;
        if(GPIOx->Mode == GPIO_Mode_IN_FLOATING)    P5M0 &= ~GPIOx->Pin, P5M1 |=  GPIOx->Pin;
		if(GPIOx->Mode == GPIO_Mode_Out_PP)         P5M0 |=  GPIOx->Pin, P5M1 &= ~GPIOx->Pin;
		if(GPIOx->Mode == GPIO_Mode_Out_OD)         P5M0 |=  GPIOx->Pin, P5M1 |=  GPIOx->Pin;
    }
    if(GPIO == GPIO_P6)
    {
		if(GPIOx->Mode == GPIO_Mode_Out_IN)         P6M0 &= ~GPIOx->Pin, P6M1 &= ~GPIOx->Pin;
        if(GPIOx->Mode == GPIO_Mode_IN_FLOATING)    P6M0 &= ~GPIOx->Pin, P6M1 |=  GPIOx->Pin;
		if(GPIOx->Mode == GPIO_Mode_Out_PP)         P6M0 |=  GPIOx->Pin, P6M1 &= ~GPIOx->Pin;
		if(GPIOx->Mode == GPIO_Mode_Out_OD)         P6M0 |=  GPIOx->Pin, P6M1 |=  GPIOx->Pin;
    }
    if(GPIO == GPIO_P7)
    {
		if(GPIOx->Mode == GPIO_Mode_Out_IN)         P7M0 &= ~GPIOx->Pin, P7M1 &= ~GPIOx->Pin;
        if(GPIOx->Mode == GPIO_Mode_IN_FLOATING)    P7M0 &= ~GPIOx->Pin, P7M1 |=  GPIOx->Pin;
		if(GPIOx->Mode == GPIO_Mode_Out_PP)         P7M0 |=  GPIOx->Pin, P7M1 &= ~GPIOx->Pin;
		if(GPIOx->Mode == GPIO_Mode_Out_OD)         P7M0 |=  GPIOx->Pin, P7M1 |=  GPIOx->Pin;
    }
}
/*************************************************************************
 * @code    void GPIO_Init(GPIO_port GPIO_Port,u8 GPIO_Pin_Bit, GPIO_Mode Mode_e)
 * @brief   һ������GPIO�˿ڵĶ��IOģʽ
 * @param   GPIO_Port:�˿ںţ�0~7����GPIO_Pin_Bit������λ�ţ�Mode_e��ģʽ
 *          ģʽѡ��GPIO_Mode_Out_IN/GPIO_Mode_IN_FLOATING/GPIO_Mode_Out_PP/GPIO_Mode_Out_OD
 * @return  ��
 * @date    2025-10-22.
 * @example GPIO_Init(GPIO_P2,GPIO_Pin_0|GPIO_Pin_1,GPIO_Mode_Out_IN);
 *          ���� P2.0 P2.1 �ܽ�׼˫��ģʽ�����������Ҳ��������
 * ***********************************************************************/
void GPIO_Init(GPIO_port GPIO_Port,u8 GPIO_Pin_Bit, GPIO_Mode Mode_e)
{
    GPIO_InitTypeDef GPIO_Initstu;

    GPIO_Initstu.Pin  = GPIO_Pin_Bit;        //Ҫ��ʼ����I/O  eg: GPIO_Pin_0|GPIO_Pin_2;
    GPIO_Initstu.Mode = Mode_e;              //Ҫ��ʼ����I/O ģʽ
    GPIO_Config(GPIO_Port,&GPIO_Initstu);
}

/*************************************************************************
 * @code    void GPIO_Set_Out_IN(Pin_list Pin_x);
 * @brief   ��������׼˫��ģʽ���ú����û�����Ҫ��
 * @param   Pin_x:���ź�
 * @return  ��
 * @date    2025-10-22.
 * @example GPIO_Set_Out_IN(P2_0); // ���� P2_0 �ܽ�׼˫��ģʽ�����������Ҳ��������
 * ***********************************************************************/
void GPIO_Set_Out_IN(Pin_list Pin_x)
{
    u8 Pin_Bit = GPIO_Get_Pin(Pin_x);
    switch (GPIO_Get_Port(Pin_x))
    {
        case GPIO_P0: P0M0 &= ~Pin_Bit, P0M1 |= Pin_Bit; break;
        case GPIO_P1: P1M0 &= ~Pin_Bit, P1M1 |= Pin_Bit; break;
        case GPIO_P2: P2M0 &= ~Pin_Bit, P2M1 |= Pin_Bit; break;
        case GPIO_P3: P3M0 &= ~Pin_Bit, P3M1 |= Pin_Bit; break;
        case GPIO_P4: P4M0 &= ~Pin_Bit, P4M1 |= Pin_Bit; break;
        case GPIO_P5: P5M0 &= ~Pin_Bit, P5M1 |= Pin_Bit; break;
        case GPIO_P6: P6M0 &= ~Pin_Bit, P6M1 |= Pin_Bit; break;
        case GPIO_P7: P7M0 &= ~Pin_Bit, P7M1 |= Pin_Bit; break;
        default: break;
    }
}
/*************************************************************************
 * @code    void GPIO_Set_IN_FLOATING(Pin_list Pin_x);
 * @brief   ��������Ϊ��������ģʽ���ú����û�����Ҫ��
 * @param   Pin_x:���ź�
 * @return  ��
 * @date    2025-10-22.
 * @example GPIO_Set_IN_FLOATING(P2_0); // ���� P2_0 �ܽ�Ϊ��������
 * ***********************************************************************/
void GPIO_Set_IN_FLOATING(Pin_list Pin_x)
{
    u8 Pin_Bit = GPIO_Get_Pin(Pin_x);
    switch (GPIO_Get_Port(Pin_x))
    {
        case GPIO_P0: P0M0 &= ~Pin_Bit, P0M1 |= Pin_Bit; break;
        case GPIO_P1: P1M0 &= ~Pin_Bit, P1M1 |= Pin_Bit; break;
        case GPIO_P2: P2M0 &= ~Pin_Bit, P2M1 |= Pin_Bit; break;
        case GPIO_P3: P3M0 &= ~Pin_Bit, P3M1 |= Pin_Bit; break;
        case GPIO_P4: P4M0 &= ~Pin_Bit, P4M1 |= Pin_Bit; break;
        case GPIO_P5: P5M0 &= ~Pin_Bit, P5M1 |= Pin_Bit; break;
        case GPIO_P6: P6M0 &= ~Pin_Bit, P6M1 |= Pin_Bit; break;
        case GPIO_P7: P7M0 &= ~Pin_Bit, P7M1 |= Pin_Bit; break;
        default: break;
    }
}

/*************************************************************************
 * @code    void GPIO_Set_Out_PP(Pin_list Pin_x);
 * @brief   ��������Ϊ�������ģʽ���ú����û�����Ҫ��
 * @param   Pin_x:���ź�
 * @return  ��
 * @date    2025-10-22.
 * @example GPIO_Set_Out_PP(P2_0); // ���� P2_0 �ܽ�Ϊ�������
 * ***********************************************************************/
void GPIO_Set_Out_PP(Pin_list Pin_x)
{
    u8 Pin_Bit = GPIO_Get_Pin(Pin_x);
    switch (GPIO_Get_Port(Pin_x))
    {
        case GPIO_P0: P0M0 |= Pin_Bit, P0M1 &= ~Pin_Bit; break;
        case GPIO_P1: P1M0 |= Pin_Bit, P1M1 &= ~Pin_Bit; break;
        case GPIO_P2: P2M0 |= Pin_Bit, P2M1 &= ~Pin_Bit; break;
        case GPIO_P3: P3M0 |= Pin_Bit, P3M1 &= ~Pin_Bit; break;
        case GPIO_P4: P4M0 |= Pin_Bit, P4M1 &= ~Pin_Bit; break;
        case GPIO_P5: P5M0 |= Pin_Bit, P5M1 &= ~Pin_Bit; break;
        case GPIO_P6: P6M0 |= Pin_Bit, P6M1 &= ~Pin_Bit; break;
        case GPIO_P7: P7M0 |= Pin_Bit, P7M1 &= ~Pin_Bit; break;
        default: break;
    }
}

/*************************************************************************
 * @code    void GPIO_Set_Out_OD(Pin_list Pin_x);
 * @brief   ��������Ϊ��©ģʽ���ú����û�����Ҫ��
 * @param   Pin_x:���ź�
 * @return  ��
 * @date    2025-10-22.
 * @example GPIO_Set_Out_OD(P2_0); // ���� P2_0 �ܽ�Ϊ��©���
 * ***********************************************************************/
void GPIO_Set_Out_OD(Pin_list Pin_x)
{
    u8 Pin_Bit = GPIO_Get_Pin(Pin_x);
    switch (GPIO_Get_Port(Pin_x))
    {
        case GPIO_P0: P0M0 |= Pin_Bit, P0M1 |= Pin_Bit; break;
        case GPIO_P1: P1M0 |= Pin_Bit, P1M1 |= Pin_Bit; break;
        case GPIO_P2: P2M0 |= Pin_Bit, P2M1 |= Pin_Bit; break;
        case GPIO_P3: P3M0 |= Pin_Bit, P3M1 |= Pin_Bit; break;
        case GPIO_P4: P4M0 |= Pin_Bit, P4M1 |= Pin_Bit; break;
        case GPIO_P5: P5M0 |= Pin_Bit, P5M1 |= Pin_Bit; break;
        case GPIO_P6: P6M0 |= Pin_Bit, P6M1 |= Pin_Bit; break;
        case GPIO_P7: P7M0 |= Pin_Bit, P7M1 |= Pin_Bit; break;
        default: break;
    }
}
/*************************************************************************
 * @code    void gpio_init_pin(Pin_list Pin_x, GPIO_Mode mode);
 * @brief   �û����� GPIO���ų�ʼ������.
 * @param   Pin_x  ���ܽű��.
 * @param   mode   ��IOģʽ, ->  GPIO_Mode
 * @return  none.
 * @date    2025-10-22.
 * @example gpio_init_pin(P2_0, GPIO_Mode_Out_PP); // ��ʼ�� P2_0 �ܽ�Ϊ�������
 *************************************************************************/
void gpio_init_pin(Pin_list Pin_x, GPIO_Mode mode)
{
    switch (mode)
    {
        case GPIO_Mode_Out_IN:
		    GPIO_Set_Out_IN(Pin_x);
			break;
        case GPIO_Mode_IN_FLOATING:
            GPIO_Set_IN_FLOATING(Pin_x); /* �������� ����̬ ��������*/
            break;
        case GPIO_Mode_IPU:
            GPIO_Set_IN_FLOATING(Pin_x); /* ������Ϊ�������� ��ʹ������ */
            gpio_pull_up(Pin_x, ENABLE);
            break;
        case GPIO_Mode_IPD:
            GPIO_Set_IN_FLOATING(Pin_x); /* ������Ϊ�������� ��ʹ������ */
            gpio_pull_down(Pin_x, ENABLE);
            break;
        case GPIO_Mode_Out_PP:
            GPIO_Set_Out_PP(Pin_x);     /* ������������������û�ѡ���Ƿ�ǿ������IO�ٶ� */
            break;
        case GPIO_Mode_Out_OD:
            GPIO_Set_Out_OD(Pin_x);    /* ͨ�ÿ�©ģʽ����©���ɶ�ȡ�ⲿ״̬ Ҳ�ɶ�������ߵ͵�ƽ */
            break;
    default:  break;
    }
}

/*************************************************************************
 * @code    void gpio_pull_up(Pin_list Pin_x, u8 enable)
 * @brief   GPIO��������ʹ������.
 * @param   Pin_x  ���ܽű��.
 * @param   enable ��ʹ�ܱ�־, ENABLE-ʹ��, DISABLE-��ֹ.
 * @return  none.
 * @date    2025-12-22.
 * @example gpio_pull_up(P2_0, ENABLE); // ���� P2_0 �ܽ�����
 *************************************************************************/
void gpio_pull_up(Pin_list Pin_x, u8 _enable)
{
    u8 port_offset = GPIO_Get_Port(Pin_x), pin_num = GPIO_Get_Pin(Pin_x);
    if (Pin_x <= P7_7)
	{
		(_enable == ENABLE) ? ((*(&P0PU + port_offset) |= pin_num)) : ((*(&P0PU + port_offset) &= ~pin_num));
	}
}

/*************************************************************************
 * @code    void gpio_pull_down(Pin_list pin, u8 enable)
 * @brief   GPIO��������ʹ������.
 * @param   Pin_x  ���ܽű��.
 * @param   enable ��ʹ�ܱ�־, ENABLE-ʹ��, DISABLE-��ֹ.
 * @return  none.
 * @date    2025-12-22.
 * @example GPIO_down_up(P2_0, ENABLE); // ���� P2_0 �ܽ�����
 *************************************************************************/
void gpio_pull_down(Pin_list Pin_x, u8 _enable)
{
    u8 port_offset = GPIO_Get_Port(Pin_x), pin_num = GPIO_Get_Pin(Pin_x);
    if (Pin_x <= P7_7)
	{
    	(_enable == ENABLE) ? ((*(&P0PD + port_offset)) |= pin_num) : ((*(&P0PD + port_offset) &= ~pin_num));
	}
}

/*************************************************************************
 * @code    void GPIO_ncs(Pin_list pin, u8 enable)
 * @brief   GPIO����ʩ���ش���������ʹ������.
 * @param   Pin_x  ���ܽű��.
 * @param   enable ��ʹ�ܱ�־, ENABLE-ʹ��, DISABLE-��ֹ.
 * @return  none.
 * @date    2025-10-22.
 * @example GPIO_ncs(P2_0, ENABLE); // ���� P2_0 �ܽ�ʹ��ʩ���ش���������
 *************************************************************************/
void gpio_en_ncs(Pin_list Pin_x, u8 _enable)
{
    u8 port_offSet = GPIO_Get_Port(Pin_x), pin_num = GPIO_Get_Pin(Pin_x);
    if (Pin_x <= P7_7)
    {
        (_enable == ENABLE) ? ((*(&P0NCS + port_offSet)) |= pin_num) : ((*(&P0NCS + port_offSet) &= ~pin_num));
    }
}

/*************************************************************************
 * @code    void gpio_speed(Pin_list pin, u8 enable)
 * @brief   GPIO���ŵ�ƽת���ٶ�ʹ������.
 * @param   Pin_x  ���ܽű��.
 * @param   enable ��ʹ�ܱ�־, ENABLE-ʹ��, DISABLE-��ֹ.
 * @return  none.
 * @date    2025-12-22.
 * @example GPIO_speed(P2_0, ENABLE); // ���� P2_0 �ܽŵ�ƽת���ٶȿ�
 *************************************************************************/
void gpio_speed(Pin_list Pin_x, u8 _enable)
{
    u8 port_offSet = GPIO_Get_Port(Pin_x), pin_num = GPIO_Get_Pin(Pin_x);
    if (Pin_x <= P7_7)
    {
        (_enable == ENABLE) ? ((*(&P0SR + port_offSet)) |= pin_num) : ((*(&P0SR + port_offSet) &= ~pin_num));
    }
}

/*************************************************************************
 * @code    void gpio_electricity(Pin_list pin, u8 enable)
 * @brief   GPIO���Ŷ˿���������ʹ�ܿ���.
 * @param   Pin_x  ���ܽű��.
 * @param   enable ��ʹ�ܱ�־, ENABLE-ǿ��������, DISABLE-����������.
 * @return  none.
 * @date    2025-12-22.
 * @example GPIO_electricity(P2_0, ENABLE); // ���� P2_0 �ܽ���ǿ���ƶ˿ڵ���������
 *************************************************************************/
void gpio_electricity(Pin_list Pin_x, u8 _enable)
{
    u8 port_offSet = GPIO_Get_Port(Pin_x), pin_num = GPIO_Get_Pin(Pin_x);
    if (Pin_x <= P7_7)
    {
        (_enable == ENABLE) ? ((*(&P0DR + port_offSet) &= ~pin_num)) : ((*(&P0DR + port_offSet)) |= pin_num);
    }
}

/*************************************************************************
 * @code    void gpio_en_digital(Pin_list Pin_x, u8 _enable)
 * @brief   GPIO���������ź�����ʹ�ܿ���.
 * @param   Pin_x  ���ܽű��.
 * @param   enable ��ʹ�ܱ�־, ENABLE-ʹ��, DISABLE-��ֹ.
 * @return  none.
 * @date    2025-12-22.
 * @example gpio_en_digital(P2_0, ENABLE); // ʹ�� P2_0 �ܽ������ź�����
 *************************************************************************/
void gpio_en_digital(Pin_list Pin_x, u8 _enable)
{
    u8 port_offSet = GPIO_Get_Port(Pin_x), pin_num = GPIO_Get_Pin(Pin_x);
    if (Pin_x <= P7_7)
    {
        (_enable == ENABLE) ? ((*(&P0IE + port_offSet)) |= pin_num) : ((*(&P0IE + port_offSet) &= ~pin_num));
    }
}

/*************************************************************************
 * @code    void gpio_AF_mode(Pin_list Pin_x, u8 _mode)
 * @brief   GPIO��������ģʽ����.Ĭ���û�����
 * @param   Pin_x  ���ܽű��.
 * @param   _mode ������ģʽ, ENABLE-�����Զ�����-������ģʽ. DISABLE-�û���������,
 * @return  none.
 * @date    2025-12-22.
 * @example gpio_AF_mode(P2_0, ENABLE); // ���� P2_0 �ܽ�Ϊ�����Զ�����ģʽ
 *************************************************************************/
void gpio_AF_mode(Pin_list Pin_x, u8 _mode)
{
    u8 port_offSet = GPIO_Get_Port(Pin_x), pin_num = GPIO_Get_Pin(Pin_x);
    if (Pin_x <= P7_7)
    {
        (_mode == ENABLE) ? ((*(&P0BP + port_offSet) &= ~pin_num)) : ((*(&P0BP + port_offSet)) |= pin_num);
    }
}

/*************************************************************************
 * @code    void gpio_write_pin(Pin_list Pin_x,u8 value)
 * @brief   GPIO���ŵ�ƽ״̬.
 * @param   Pin_x ���ܽű��.
 * @param   value ����ƽ״̬���ã�1-ʹ�ܣ�0-��ֹ.
 * @return  none.
 * @date    2025-11-12.
 * @example gpio_write_pin(P0_0, ENABLE);  // P0_0����ʹ��
 *************************************************************************/
void gpio_write_pin(Pin_list Pin_x, u8 value)
{
    switch (GPIO_Get_Port(Pin_x))
    {
        case GPIO_P0: if (value) P0 |= GPIO_Get_Pin(Pin_x); else P0 &= ~GPIO_Get_Pin(Pin_x); break;
        case GPIO_P1: if (value) P1 |= GPIO_Get_Pin(Pin_x); else P1 &= ~GPIO_Get_Pin(Pin_x); break;
        case GPIO_P2: if (value) P2 |= GPIO_Get_Pin(Pin_x); else P2 &= ~GPIO_Get_Pin(Pin_x); break;
        case GPIO_P3: if (value) P3 |= GPIO_Get_Pin(Pin_x); else P3 &= ~GPIO_Get_Pin(Pin_x); break;
        case GPIO_P4: if (value) P4 |= GPIO_Get_Pin(Pin_x); else P4 &= ~GPIO_Get_Pin(Pin_x); break;
        case GPIO_P5: if (value) P5 |= GPIO_Get_Pin(Pin_x); else P5 &= ~GPIO_Get_Pin(Pin_x); break;
        case GPIO_P6: if (value) P6 |= GPIO_Get_Pin(Pin_x); else P6 &= ~GPIO_Get_Pin(Pin_x); break;
        case GPIO_P7: if (value) P7 |= GPIO_Get_Pin(Pin_x); else P7 &= ~GPIO_Get_Pin(Pin_x); break;
        default: break;
    }
}

/*************************************************************************
 * @code    u8 gpio_read_pin(Pin_list Pin_x)
 * @brief   ��ȡ�� GPIO ���ŵ�ƽ״̬.
 * @param   Pin_x ���ܽű��.
 * @return  �ܽŵ�ƽ״̬.1/0
 * @date    2025-11-12.
 * @example u8 val = gpio_read_pin(P0_0);  // ��ȡP0_0��ƽ״̬
 *************************************************************************/
u8 gpio_read_pin(Pin_list Pin_x)
{
    u8 val = FAIL;    // Ĭ�Ϸ��ش���״̬
     switch (GPIO_Get_Port(Pin_x))
     {
         case GPIO_P0: val = (P0 & GPIO_Get_Pin(Pin_x)) ? 1 : 0; break;
         case GPIO_P1: val = (P1 & GPIO_Get_Pin(Pin_x)) ? 1 : 0; break;
         case GPIO_P2: val = (P2 & GPIO_Get_Pin(Pin_x)) ? 1 : 0; break;
         case GPIO_P3: val = (P3 & GPIO_Get_Pin(Pin_x)) ? 1 : 0; break;
         case GPIO_P4: val = (P4 & GPIO_Get_Pin(Pin_x)) ? 1 : 0; break;
         case GPIO_P5: val = (P5 & GPIO_Get_Pin(Pin_x)) ? 1 : 0; break;
         case GPIO_P6: val = (P6 & GPIO_Get_Pin(Pin_x)) ? 1 : 0; break;
         case GPIO_P7: val = (P7 & GPIO_Get_Pin(Pin_x)) ? 1 : 0; break;
         default: break;
     }
    return val;
}

/*************************************************************************
 * @code    void gpio_toggle_pin(Pin_list Pin_x)
 * @brief   GPIO���ŵ�ƽ���״̬��ת.
 * @param   Pin_x ���ܽű��.
 * @return  none.
 * @date    2025-11-12.
 * @example gpio_toggle_pin(P0_0);  // P0_0��ƽ״̬��ת
 *************************************************************************/
void gpio_toggle_pin(Pin_list Pin_x)
{
    switch (GPIO_Get_Port(Pin_x))
    {
        case GPIO_P0: P0 ^= GPIO_Get_Pin(Pin_x); break;
        case GPIO_P1: P1 ^= GPIO_Get_Pin(Pin_x); break;
        case GPIO_P2: P2 ^= GPIO_Get_Pin(Pin_x); break;
        case GPIO_P3: P3 ^= GPIO_Get_Pin(Pin_x); break;
        case GPIO_P4: P4 ^= GPIO_Get_Pin(Pin_x); break;
        case GPIO_P5: P5 ^= GPIO_Get_Pin(Pin_x); break;
        case GPIO_P6: P6 ^= GPIO_Get_Pin(Pin_x); break;
        case GPIO_P7: P7 ^= GPIO_Get_Pin(Pin_x); break;
        default: break;
    }
}
